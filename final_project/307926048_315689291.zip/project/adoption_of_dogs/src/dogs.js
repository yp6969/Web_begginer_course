var dogs = [
  {
    avilabe: true,
    name: 'spotnik',
    url: 'https://thumbs.dreamstime.com/z/halloween-ghost-portrait-funny-dog-black-background-adorable-pup-muzle-153863580.jpg',
    description: '',
  },
  {
    avilabe: true,
    name: 'flafi',
    url: 'https://i.pinimg.com/564x/1b/64/c4/1b64c4acd6b04c1cfe3767d7a23f166a.jpg',
    description: '',
  },
  {
    avilabe: true,
    name: 'rexi',
    url: 'https://i.pinimg.com/564x/2a/a4/83/2aa483f04f1270a328827d7f365e5b6b.jpg',
    description: '',
  },
  {
    avilabe: true,
    name: 'Amram',
    url: 'https://i.pinimg.com/originals/b5/54/31/b554314a35ba0c312ecc7d36aab0bceb.png',
    description: '',
  },
  {
    avilabe: true,
    name: 'putin',
    url: 'https://w0.peakpx.com/wallpaper/933/448/HD-wallpaper-pitbull-muscles-big-fighter-strong.jpg',
    description: '',
  },
  {
    avilabe: true,
    name: 'buf',
    url: 'https://www.askideas.com/media/26/Black-Pit-Bull-Dog-Photo.jpg',
    description: '',
  },
  {
    avilabe: true,
    name: 'Itzik',
    url: 'https://i.pinimg.com/564x/43/34/65/433465465f701570ec543bea8d7afa8c.jpg',
    description: '',
  },
  {
    avilabe: true,
    name: 'Yakov',
    url: 'https://i.pinimg.com/564x/54/33/82/543382da3f9533daefbad46762bdd661.jpg',
    description: '',
  },
];
